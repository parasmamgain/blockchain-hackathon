#!/usr/bin/python3

# Module for collection for the rules application simulation

class Rules(object):
	"""docstring for Rules"""
	def __init__(self, arg):
		super(Rules, self).__init__()
		self.arg = arg

	# RTO_approval = True
	# BBMP_approval = True
    #
	# def is_RTO_approval():
    #
	# 	# update the block chain with the status or the process
	# 	return self.RTO_approval
    #
	# def is_BBMP_approval():
    #
	# 	# update the block chain with the status or the process
	# 	return self.BBMP_approval
    #

# TODO: Design this class!
