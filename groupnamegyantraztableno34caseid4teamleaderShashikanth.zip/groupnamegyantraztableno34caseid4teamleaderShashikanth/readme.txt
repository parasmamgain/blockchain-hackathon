Project Green
Provides source code for the whole project of Project Green Designed by Gyantraz Team Source code compiled by Shashikanth R gzgreensolutions@gmail.com

We designed this model at Blockchain hackathon conducted at hotel ashoka during 19 to 21 all the source code is executed through smart conctracts deployed at ethereum purlic network you can download the code from smart contracts at

0xa17719BaCf79a8c15E2269A07fFC16Ee1f32D993 Digital Assets Created YSVTWO 0x60E6B603B34b39ed22e95C10f360AFdE8a88D1e9 Digital Assets Created YSVONE 0x811B98623EA8f4Da5EFD64181cc0d9920d7A7061 Digital Assets Created YSR 0xB1feAeca74E99d3E974DBe13f3f87b4b3D26bAFA Digital Assets Created SAP 0xFD87dA04C3701D44e89809d4eE21E35154735924 Digital Assets Created KLAND 0xc2de2ce66f1f16c09e6a2c9595ac878db4113a88 Digital Assets Created SV3

All the digital assets created are ERC 20 Tokens and one can start trading in any decentralised exchanges. The project is not a prototype and it is fully executable for day One Hope this effort will provide address not only Deforestation propblem in Karnataka But also Formers Debt Problem Thank You Gyantraz Team

Solution Offered We identified Transactions will result in between a) Farmers (Grow Sapplings) OWN and SELL all The digital assets or Redeem Yearly Sappling Voucehrs with Government b) Forest Department (Inspect Sapling) and issue YSR digital asset to revenue department for issue of Yearly Sappling Vouchers using automated Exchanges c)Revenue Department Issue KLAND digital record to farmers which monitors area of land used for deforestation and sapplings grown using the land: This data is vital and available in public network. d)Nurseries : Issue digital record of sapplings distributed to farmers

Out of the Box Solutions The initial problem was addressing Deforestation and We thought it will also provide unique innovative solution for farmers in addressing their debt trap We created a decentralised Exchange for farmers to liquidated their Yearly Sappling Vouchers for raising future finance We also suggest government of karnataka to create Similar kind of digital solutions for farmers in exchaning their produced goods. Govenrment also can raise finance against Yearly sappling Voucher using ICO route or Discounted Asset Bargaining Mode

Start Buying YSV Vouchers at https://etherdelta.com/#0x60e6b603b34b39ed22e95c10f360afde8a88d1e9-ETH and Help Farmers

The Digital Assets Exchange model has been demonstrated using 0Xprotocal and one can start using at https://0xproject.com/portal

Idea designed by Shashikanth R and you can reach shashikanth2005@gmail.com/9632591399

The Project hosted at https://greenyantaz.azurewebsites.net/index.html We have also created ethereum private network at http://gyantraz.eastus.cloudapp.azure.com/